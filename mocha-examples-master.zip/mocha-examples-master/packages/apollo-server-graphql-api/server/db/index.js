const user = [
    { name: "admin", age: 22 },
    { name: "test", age: 31 },
    { name: "kim", age: 21 },
];

module.exports = user;
