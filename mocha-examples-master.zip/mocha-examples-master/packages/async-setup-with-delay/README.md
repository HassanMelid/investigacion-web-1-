# Async setup with --delay

A simple async setup with `--delay`.

## Commands

- `npm test` - run the tests using the local `.mocharc.json` config file. The config includes a `--delay` to perform asynchronous operations.
