# Async setup with --file

A simple async setup with `--file` and root hooks.

## Commands

- `npm test` - run the tests using the local `.mocharc.json` config file. The config includes a `--file` to be loaded prior to the root suite execution.
