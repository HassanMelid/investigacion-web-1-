export default (a, b) => {
  return a + b;
}
