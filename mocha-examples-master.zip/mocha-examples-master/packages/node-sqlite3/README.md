# database example

This example demonstrates how you can create tests on an Database using Mocha.js. [node-sqlite3](https://github.com/mapbox/node-sqlite3) is used to connect to a local sqlite database.

## Commands

- No config file is needed for Mocha as the app uses default values
- `npm test` - run the mocha test code
