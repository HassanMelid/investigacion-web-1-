# Playwright

Basic example for mocha and playwright(`^1.9.1`)

## Commands

- `npm test` - Run mocha test. Visit [Mocha Page](https://mochajs.org) and assert actual text on Chromium.
