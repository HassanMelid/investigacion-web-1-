# Programmatic usage

Full documentation about it [here](https://github.com/mochajs/mocha/wiki/Using-Mocha-programmatically)

## Commands

- `npm test` - run our tests calling Mocha programatically found in `index.js`. The options are handed to mocha when it is instantiated.
