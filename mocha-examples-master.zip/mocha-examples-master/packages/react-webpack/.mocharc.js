module.exports = {
  require: '@babel/register',
  extension: ['js']
};
