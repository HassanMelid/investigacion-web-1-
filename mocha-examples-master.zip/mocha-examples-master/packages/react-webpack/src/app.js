import React from 'react';

export default () => (<h1>Welcome to the React application.</h1>);
