# RxJs examples

Mocha test examples with marble diagram for RxJs(6.6.3).

This example focus on how to handle source properties and test process is described for observable streams handling properties.

First test proves an use case for marble diagram and helps understand basic operators of Observable.

Second test show a practical use case with Observable and custom operators by users.

## Commands

- `npm test` - Run mocha tests.
