# Selenium application

Basic example running Chrome headlessly. Runs a search in Google and checks result.

## Commands

- `npm test` - run the tests using the local `.mocharc.yaml` config file. The config includes the Babel transpilation hook `@babel/register`. We have the babel config set inside `.babelrc`.
