export default function(name: string) {
  return `Hello ${name}`;
}
