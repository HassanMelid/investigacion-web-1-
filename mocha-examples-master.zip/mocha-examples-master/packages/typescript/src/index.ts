export default function(incomingText: string) {
  return `${incomingText}-static`;
}
