---
name: Support Question
about: If you have a question, please check out our Gitter or StackOverflow!
title: ''
labels: 'question'
---

<!--
We primarily use GitHub as an issue tracker; for usage and support questions, please check out these resources below. Thanks!.

* Website: https://mochajs.org/
* Chat room: http://gitter.im/mochajs/mocha
* StackOverflow: https://stackoverflow.com/questions/tagged/mocha using the tag `mocha`
* API documentation: https://mochajs.org/api/
-->
