# Mocha's API Documentation

---

Congratulations! You've found Mocha's API documentation. These docs are for developers who wish to:

- Create an extension for Mocha, or
- Develop Mocha itself, or
- Do something else fancy with Mocha

Otherwise, **you probably want the [main documentation](https://mochajs.org)**.

## Other Links

- **[Main Documentation](https://mochajs.org)**
- **[Release Notes / History / Changes](https://github.com/mochajs/mocha/blob/master/CHANGELOG.md)**
- [Code of Conduct](https://github.com/mochajs/mocha/blob/master/.github/CODE_OF_CONDUCT.md)
- [Gitter Chatroom](https://gitter.im/mochajs/mocha) (ask questions here!)
- [Issue Tracker](https://github.com/mochajs/mocha/issues)
