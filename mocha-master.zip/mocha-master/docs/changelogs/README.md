# Historical Changelogs

These are changelogs for (very) old versions of Mocha.

These changelogs are _not_ included in the website, and are here only for archival purposes.

_If you're looking for the current changelog, [here is the current changelog](https://github.com/mochajs/mocha/blob/master/CHANGELOG.md)._
