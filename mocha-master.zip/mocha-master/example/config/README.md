# Mocha Configuration Examples

In this directory, you'll find example Mocha configurations for Node.js.

As of this writing, **these examples are intended to illustrate the available options; they are not intended to serve as boilerplates.**

[Read more about configuration here](https://mochajs.org/#configuring-mocha-nodejs).
