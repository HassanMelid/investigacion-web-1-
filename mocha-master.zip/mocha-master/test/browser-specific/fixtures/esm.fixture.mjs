/* eslint-disable-next-line import/no-absolute-path */
import '/base/mocha.js';
window.MOCHA_IS_OK = true;
