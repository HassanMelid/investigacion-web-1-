// this generic fixture does nothing special and will be used if no fixture is supplied

'use strict';

describe('a suite', function() {
  it('should succeed', function(done) {
    done();
  });
});
