'use strict';

describe('globbing test', function() {
  it('should find this test', function() {
    // see test/integration/glob.spec.js for details
  });
});
