'use strict';

it('throws an error', function () {});
