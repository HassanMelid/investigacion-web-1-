var obj = {foo: 'bar'};

describe('js', function () {
  it('should work', function () {
    expect(obj, 'to equal', {foo: 'bar'});
  });
});
