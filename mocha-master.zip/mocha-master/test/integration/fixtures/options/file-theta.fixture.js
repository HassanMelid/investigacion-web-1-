'use strict';

describe('theta', function () {
  it('should be executed third', function () {
    global.theta = 1;
  });
});
