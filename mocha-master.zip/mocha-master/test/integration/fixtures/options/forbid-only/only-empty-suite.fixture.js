'use strict';

describe.only('forbid only - suite marked with only', function() {});
