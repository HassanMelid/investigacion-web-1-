'use strict';

describe('forbid only - `.only` is not used', function() {
  it('test1', function() {});
  it('test2', function() {});
  it('test3', function() {});
});
