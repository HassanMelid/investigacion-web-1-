'use strict';

describe.skip('forbid pending - suite marked with skip', function() {});
