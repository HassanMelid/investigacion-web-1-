'use strict';

describe('ignore test nested pass', function () {
  it('should find this test', function () {});
});
