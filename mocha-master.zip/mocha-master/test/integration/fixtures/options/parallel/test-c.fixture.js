describe('c', function() {
  it('should fail', function() {
    throw new Error('failure');
  });
});
