import {describe,it} from "../../../../index.js";

describe('test1', () => {
  it('should pass', () => {});
});
