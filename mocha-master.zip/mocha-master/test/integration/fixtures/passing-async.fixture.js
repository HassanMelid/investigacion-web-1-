'use strict';

describe('a suite', function() {
  it('should succeed in 50ms', function(done) {
    setTimeout(done, 50);
  });
});
