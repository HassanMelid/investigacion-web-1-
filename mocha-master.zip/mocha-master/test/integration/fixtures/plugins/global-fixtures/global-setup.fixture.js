'use strict';

exports.mochaGlobalSetup = async function() {
  console.log(`setup schmetup`);
};

