// run with --require root-hook-defs-a.fixture.js --require
// root-hook-defs-b.fixture.js

it('should have some root hooks', function() {
  // test
});