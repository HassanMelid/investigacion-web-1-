'use strict';

xdescribe('a pending suite with a callback', function () {});
