'use strict';

test('pass', function () {
  // pass
});
