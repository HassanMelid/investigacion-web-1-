'use strict';

global.required = global.required || [];
global.required.push('c.js');
